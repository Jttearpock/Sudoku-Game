﻿using System;

namespace SudokuGame
{
    public class GameDifficulty
    {

        public Difficulty Easy;
        public Difficulty Medium;
        public Difficulty Hard;
        public Difficulty Expert;

        public static implicit operator string(GameDifficulty v)
        {
            throw new NotImplementedException();
        }
    }
}