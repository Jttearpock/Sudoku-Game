﻿namespace SudokuGame
{
    public class Difficulty
    {
        public string Easy;
        public string Medium;
        public string Hard;
        public string Expert;
    }
}